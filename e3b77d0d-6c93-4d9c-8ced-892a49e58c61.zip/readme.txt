Smart Gadget Finder — v2 Polished
- Fixed Tailwind: using official CDN script (previous build linked a non-existent CSS file).
- Mobile polish: balanced spacing, refined colors, bigger AI input/button, smaller logo.
- Review-safe, turnkey; Phase 2: set reviewSafe=false, add AdSense + Skimlinks snippets, replace # URLs.
